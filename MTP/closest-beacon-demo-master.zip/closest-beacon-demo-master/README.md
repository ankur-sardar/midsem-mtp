![The demo app in action](http://cdn.willd.me/images/posts/ibeacon-tutorial/app-demo.gif)

This code accompanies a full [tutorial](http://willd.me/posts/getting-started-with-ibeacon-a-swift-tutorial) and [screencast](https://www.youtube.com/watch?v=3jJiqzbzutU).
